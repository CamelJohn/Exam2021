export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyBUtOmYDfNgoOu-Uisk3Ms5g9gdBC2lu10",
    authDomain: "hello-c321a.firebaseapp.com",
    databaseURL: "https://hello-c321a.firebaseio.com",
    projectId: "hello-c321a",
    storageBucket: "hello-c321a.appspot.com",
    messagingSenderId: "1095455424229",
    appId: "1:1095455424229:web:f71e0bd0cac9e850365e0c"
  }
};
